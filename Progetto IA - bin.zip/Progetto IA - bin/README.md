# Iterated multilevel community detection for large-scale graph modularity maximization

## Requirements
* Java 15: [Azul JDK](https://www.azul.com/downloads/?version=java-15-mts)
* Python 3.8+


## Run the app
To show command options:
```
java -jar Progetto-IA-1.0.jar -help
```
Run on network <b>power</b>, saving only the <b>first</b> level on CSV files:
```
java -jar parser.jar -n power -o 1
```

## Viewer
If you want to visualize the result in an interactive way:
```
cd viewer
pip3 install -r requirements.txt
python3 viewer.py
```


